import React, { useState, useEffect, useRef } from 'react';
import { 
  Video,
  Image,
  Mic,
  Play,
  Square,
  SkipBack,
  SkipForward,
  Volume2,
  Layers,
  Settings,
  Plus,
  ChevronDown,
  Search,
  Folder,
  Music,
  Type,
  Film,
  Clock,
  Maximize2,
  MinusSquare,
  PlusSquare,
  Scissors,
  Sparkles,
  Send,
  Minimize2,
  X,
  Split,
  Wand2,
  Palette,
  Sliders,
  Move3D,
  Crop,
  RotateCcw,
  Gauge,
  Eye,
  Keyboard,
  Save,
  Share2,
  Upload,
  FileVideo,
  FileAudio,
  FileImage
} from 'lucide-react';
import { Timeline } from './components/Timeline';
import { EffectsPanel } from './components/EffectsPanel';
import AudioEditor from './pages/AudioEditor';
import { useEditorStore } from './store/editorStore';

function App() {
  const [selectedTool, setSelectedTool] = useState('video');
  const [currentTime, setCurrentTime] = useState('00:00:00:00');
  const [aiCommand, setAiCommand] = useState('');
  const [showAiPanel, setShowAiPanel] = useState(false);
  const [showAssistant, setShowAssistant] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [messages, setMessages] = useState<Array<{text: string; type: 'assistant' | 'user'}>>([]);
  const [showEffectsPanel, setShowEffectsPanel] = useState(true);
  const [activeTab, setActiveTab] = useState('edit');
  const [zoomLevel, setZoomLevel] = useState(1);
  const [currentPage, setCurrentPage] = useState('video');
  const [showMediaUpload, setShowMediaUpload] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setShowAssistant(true);
    setMessages([{
      type: 'assistant',
      text: "Welcome to Swadeshi AI Editor! You are entering the most powerful AI editing platform. Please use carefully."
    }]);

    const welcomeMessage = new SpeechSynthesisUtterance(
      "Welcome to Swadeshi AI Editor! You are entering the most powerful AI editing platform. Please use carefully."
    );
    welcomeMessage.rate = 0.9;
    welcomeMessage.pitch = 1;
    window.speechSynthesis.speak(welcomeMessage);
  }, []);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0])
          .map((result) => result.transcript)
          .join('');

        if (transcript.toLowerCase().includes('ashwini')) {
          setShowAssistant(true);
          setMinimized(false);
        }
      };

      if (isListening) {
        recognition.start();
      }

      return () => {
        recognition.stop();
      };
    }
  }, [isListening]);

  const handleAiCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (aiCommand.trim()) {
      setMessages(prev => [...prev, { type: 'user', text: aiCommand }]);
      setAiCommand('');
    }
  };

  const toggleListening = () => {
    setIsListening(!isListening);
  };

  const handleFileUpload = (type: 'video' | 'audio' | 'image') => {
    if (fileInputRef.current) {
      fileInputRef.current.accept = type === 'video' 
        ? '.mp4,.mov,.avi'
        : type === 'audio'
          ? '.mp3,.wav,.ogg'
          : '.jpg,.jpeg,.png,.gif';
      fileInputRef.current.click();
    }
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Handle file upload logic here
    console.log('File selected:', file);
    setShowMediaUpload(false);
  };

  const extractAudioFromVideo = async (videoFile: File) => {
    // This would typically be handled by a backend service
    // For now, we'll show a message
    setMessages(prev => [...prev, {
      type: 'assistant',
      text: "Starting audio extraction from video. This process will be handled by our AI processing engine."
    }]);
  };

  if (currentPage === 'audio') {
    return <AudioEditor />;
  }

  const tools = [
    { icon: <Scissors size={20} />, name: 'Cut', shortcut: 'C' },
    { icon: <Split size={20} />, name: 'Split', shortcut: 'S' },
    { icon: <Wand2 size={20} />, name: 'Effects', shortcut: 'E' },
    { icon: <Palette size={20} />, name: 'Color', shortcut: 'G' },
    { icon: <Sliders size={20} />, name: 'Adjust', shortcut: 'A' },
    { icon: <Move3D size={20} />, name: 'Transform', shortcut: 'T' },
    { icon: <Crop size={20} />, name: 'Crop', shortcut: 'R' },
    { icon: <RotateCcw size={20} />, name: 'Rotate', shortcut: 'O' },
  ];

  return (
    <div className="h-screen bg-[#1a1a1a] text-white flex flex-col">
      {/* Top Bar */}
      <div className="h-12 bg-[#252525] border-b border-[#333] flex items-center justify-between px-4">
        <div className="flex items-center space-x-4">
          <h1 className="text-xl font-bold">Swadeshi AI Editor</h1>
          <div className="flex space-x-2">
            <button className="px-3 py-1 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-1">
              <Save size={16} />
              <span>Save</span>
            </button>
            <button className="px-3 py-1 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-1">
              <Share2 size={16} />
              <span>Export</span>
            </button>
            <button 
              className={`px-3 py-1 rounded flex items-center space-x-1 ${showAiPanel ? 'bg-blue-600' : 'bg-[#333] hover:bg-[#444]'}`}
              onClick={() => setShowAiPanel(!showAiPanel)}
            >
              <Sparkles size={16} />
              <span>AI Edit</span>
            </button>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-[#333] rounded px-2">
            <Gauge size={16} />
            <span className="text-sm">Performance: Optimal</span>
          </div>
          <div className="flex items-center space-x-2">
            <Eye size={16} />
            <select className="bg-[#333] rounded px-2 py-1">
              <option>Preview: Full</option>
              <option>Preview: Half</option>
              <option>Preview: Quarter</option>
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <Keyboard size={16} />
            <button className="bg-[#333] rounded px-2 py-1">Shortcuts</button>
          </div>
          <Settings size={20} className="cursor-pointer hover:text-blue-400" />
        </div>
      </div>

      {/* Tool Bar */}
      <div className="h-12 bg-[#252525] border-b border-[#333] flex items-center px-4 space-x-2">
        {tools.map((tool) => (
          <button
            key={tool.name}
            className="px-3 py-1 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-1"
            title={`${tool.name} (${tool.shortcut})`}
          >
            {tool.icon}
            <span className="text-sm">{tool.name}</span>
          </button>
        ))}
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Left Sidebar - Media Library */}
        <div className="w-64 bg-[#252525] border-r border-[#333] flex flex-col">
          <div className="p-4 border-b border-[#333]">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold">Media Pool</h2>
              <button 
                onClick={() => setShowMediaUpload(!showMediaUpload)}
                className="p-2 bg-blue-600 rounded-full hover:bg-blue-700 flex items-center justify-center"
              >
                <Plus size={16} />
              </button>
            </div>
            <div className="flex space-x-2">
              <button className="p-2 bg-[#333] rounded hover:bg-[#444]">
                <Folder size={16} />
              </button>
              <button className="p-2 bg-[#333] rounded hover:bg-[#444]">
                <Film size={16} />
              </button>
              <button className="p-2 bg-[#333] rounded hover:bg-[#444]">
                <Music size={16} />
              </button>
              <button className="p-2 bg-[#333] rounded hover:bg-[#444]">
                <Type size={16} />
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            {/* Empty state message */}
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <Upload size={48} className="mb-4" />
              <p className="text-sm text-center">
                Click the + button above to add media files
              </p>
            </div>
          </div>
        </div>

        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col">
          {/* Preview Windows */}
          <div className="flex-1 flex">
            <div className="flex-1 border-r border-[#333] p-4 flex flex-col">
              <div className="text-sm font-semibold mb-2 flex items-center justify-between">
                <span>Source</span>
                <div className="flex items-center space-x-2">
                  <button className="p-1 hover:bg-[#333] rounded">
                    <Maximize2 size={14} />
                  </button>
                </div>
              </div>
              <div className="flex-1 bg-[#111] rounded flex items-center justify-center">
                <div className="text-center">
                  <Upload size={48} className="mx-auto mb-4 text-gray-400" />
                  <p className="text-sm text-gray-400">No media selected</p>
                </div>
              </div>
            </div>
            <div className="flex-1 p-4 flex flex-col">
              <div className="text-sm font-semibold mb-2 flex items-center justify-between">
                <span>Output</span>
                <div className="flex items-center space-x-2">
                  <button className="p-1 hover:bg-[#333] rounded">
                    <Maximize2 size={14} />
                  </button>
                </div>
              </div>
              <div className="flex-1 bg-[#111] rounded flex items-center justify-center">
                <div className="text-center">
                  <Upload size={48} className="mx-auto mb-4 text-gray-400" />
                  <p className="text-sm text-gray-400">No output preview</p>
                </div>
              </div>
            </div>
          </div>

          {/* AI Command Panel */}
          {showAiPanel && (
            <div className="bg-[#252525] border-t border-[#333] p-4">
              <form onSubmit={handleAiCommand} className="flex space-x-4">
                <input
                  type="text"
                  value={aiCommand}
                  onChange={(e) => setAiCommand(e.target.value)}
                  placeholder="Type your editing command (e.g., 'Add dramatic music to selected clip')"
                  className="flex-1 bg-[#333] text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg flex items-center space-x-2"
                >
                  <Send size={16} />
                  <span>Execute</span>
                </button>
              </form>
            </div>
          )}

          {/* Transport Controls */}
          <div className="h-12 border-t border-[#333] flex items-center justify-center space-x-4 bg-[#252525]">
            <div className="flex items-center space-x-2">
              <SkipBack size={20} className="cursor-pointer hover:text-blue-400" />
              <Play size={24} className="cursor-pointer hover:text-blue-400" />
              <Square size={20} className="cursor-pointer hover:text-blue-400" />
              <SkipForward size={20} className="cursor-pointer hover:text-blue-400" />
            </div>
            <div className="flex items-center space-x-4">
              <Volume2 size={20} className="cursor-pointer hover:text-blue-400" />
              <div className="w-32 h-1 bg-[#333] rounded-full">
                <div className="w-1/2 h-full bg-blue-500 rounded-full"></div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="font-mono text-sm">{currentTime}</span>
              <div className="flex items-center space-x-2">
                <button className="p-1 hover:bg-[#333] rounded">
                  <MinusSquare size={16} />
                </button>
                <span className="text-sm">{Math.round(zoomLevel * 100)}%</span>
                <button className="p-1 hover:bg-[#333] rounded">
                  <PlusSquare size={16} />
                </button>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <Timeline onClipSelect={(id) => console.log('Selected clip:', id)} />
        </div>

        {/* Effects Panel */}
        {showEffectsPanel && <EffectsPanel />}
      </div>

      {/* Media Upload Modal */}
      {showMediaUpload && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-[#252525] rounded-lg p-6 w-96">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Add Media</h3>
              <button 
                onClick={() => setShowMediaUpload(false)}
                className="p-1 hover:bg-[#333] rounded"
              >
                <X size={20} />
              </button>
            </div>
            <div className="space-y-3">
              <button
                onClick={() => handleFileUpload('video')}
                className="w-full p-3 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-3"
              >
                <FileVideo size={20} />
                <span>Upload Video</span>
              </button>
              <button
                onClick={() => handleFileUpload('audio')}
                className="w-full p-3 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-3"
              >
                <FileAudio size={20} />
                <span>Upload Audio</span>
              </button>
              <button
                onClick={() => handleFileUpload('image')}
                className="w-full p-3 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-3"
              >
                <FileImage size={20} />
                <span>Upload Image</span>
              </button>
              <button
                onClick={() => {
                  handleFileUpload('video');
                  // The actual extraction will happen after file selection
                }}
                className="w-full p-3 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-3"
              >
                <Music size={20} />
                <span>Extract Audio from Video</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        onChange={handleFileSelected}
      />

      {/* Ashwini AI Assistant */}
      {showAssistant && (
        <div 
          className={`fixed ${minimized ? 'bottom-4 right-4 w-16 h-16' : 'bottom-4 right-4 w-96 h-[480px]'} 
            bg-[#252525] rounded-lg shadow-xl border border-[#333] overflow-hidden transition-all duration-300`}
        >
          {minimized ? (
            <div 
              className="w-full h-full cursor-pointer relative"
              onClick={() => setMinimized(false)}
            >
              <img 
                src="https://raw.githubusercontent.com/your-repo/ashwini-icon.png" 
                alt="Ashwini"
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
          ) : (
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-4 border-b border-[#333]">
                <div className="flex items-center space-x-3">
                  <img 
                    src="https://raw.githubusercontent.com/your-repo/ashwini-icon.png" 
                    alt="Ashwini"
                    className="w-8 h-8 rounded-full"
                  />
                  <span className="font-semibold">Ashwini AI Assistant</span>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => setMinimized(true)}
                    className="p-1 hover:bg-[#333] rounded"
                  >
                    <Minimize2 size={16} />
                  </button>
                  <button 
                    onClick={() => setShowAssistant(false)}
                    className="p-1 hover:bg-[#333] rounded"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
              <div className="flex-1 p-4 overflow-y-auto">
                {messages.map((message, index) => (
                  <div 
                    key={index}
                    className={`mb-4 ${
                      message.type === 'assistant' 
                        ? 'bg-[#333] rounded-lg p-3' 
                        : 'bg-blue-600 rounded-lg p-3 ml-8'
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                  </div>
                ))}
              </div>
              <div className="p-4 border-t border-[#333]">
                <form onSubmit={handleAiCommand} className="flex space-x-2">
                  <input
                    type="text"
                    value={aiCommand}
                    onChange={(e) => setAiCommand(e.target.value)}
                    placeholder="Type your command or question..."
                    className="flex-1 bg-[#333] text-white px-3 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="button"
                    onClick={toggleListening}
                    className={`p-2 rounded-lg ${isListening ? 'bg-red-500' : 'bg-[#333]'} hover:opacity-80`}
                  >
                    <Mic size={20} />
                  </button>
                  <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-700 p-2 rounded-lg"
                  >
                    <Send size={20} />
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default App;