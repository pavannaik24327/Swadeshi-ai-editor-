import React, { useState } from 'react';
import { 
  Wand2,
  Sliders,
  Palette,
  Move3D,
  Crop,
  RotateCcw,
  ChevronRight,
  X
} from 'lucide-react';

export const EffectsPanel = () => {
  const [activeEffect, setActiveEffect] = useState<string | null>(null);

  const effects = [
    {
      id: 'filters',
      name: 'Filters',
      icon: <Wand2 size={20} />,
      options: ['Cinematic', 'Vintage', 'Black & White', 'Sepia', 'Vibrant']
    },
    {
      id: 'adjustments',
      name: 'Adjustments',
      icon: <Sliders size={20} />,
      options: ['Exposure', 'Contrast', 'Saturation', 'Temperature']
    },
    {
      id: 'color',
      name: 'Color',
      icon: <Palette size={20} />,
      options: ['Color Balance', 'Curves', 'Levels', 'HSL']
    },
    {
      id: 'transform',
      name: 'Transform',
      icon: <Move3D size={20} />,
      options: ['Position', 'Scale', 'Rotation', 'Skew']
    },
    {
      id: 'crop',
      name: 'Crop',
      icon: <Crop size={20} />,
      options: ['Free', '16:9', '4:3', '1:1', 'Portrait']
    },
    {
      id: 'rotate',
      name: 'Rotate',
      icon: <RotateCcw size={20} />,
      options: ['90° Left', '90° Right', '180°', 'Flip H', 'Flip V']
    }
  ];

  return (
    <div className="w-80 bg-[#252525] border-l border-[#333] flex flex-col">
      <div className="p-4 border-b border-[#333] flex items-center justify-between">
        <h2 className="font-semibold">Effects & Adjustments</h2>
        <X size={20} className="cursor-pointer hover:text-blue-400" />
      </div>
      <div className="flex-1 overflow-y-auto">
        {effects.map((effect) => (
          <div key={effect.id} className="border-b border-[#333]">
            <button
              className="w-full p-4 flex items-center justify-between hover:bg-[#333] transition-colors"
              onClick={() => setActiveEffect(activeEffect === effect.id ? null : effect.id)}
            >
              <div className="flex items-center space-x-3">
                {effect.icon}
                <span>{effect.name}</span>
              </div>
              <ChevronRight
                size={20}
                className={`transform transition-transform ${
                  activeEffect === effect.id ? 'rotate-90' : ''
                }`}
              />
            </button>
            {activeEffect === effect.id && (
              <div className="p-4 bg-[#1a1a1a] space-y-2">
                {effect.options.map((option) => (
                  <button
                    key={option}
                    className="w-full p-2 text-left hover:bg-[#333] rounded transition-colors"
                  >
                    {option}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};