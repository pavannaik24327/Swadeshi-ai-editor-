import React, { useState } from 'react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  horizontalListSortingStrategy,
} from '@dnd-kit/sortable';
import { Clock, Video, Music, Type, Layers } from 'lucide-react';

interface TimelineProps {
  onClipSelect: (id: string) => void;
}

export const Timeline: React.FC<TimelineProps> = ({ onClipSelect }) => {
  const [tracks, setTracks] = useState([
    { id: 'video-1', type: 'video', clips: [] },
    { id: 'audio-1', type: 'audio', clips: [] },
    { id: 'text-1', type: 'text', clips: [] },
    { id: 'effects-1', type: 'effects', clips: [] },
  ]);

  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(300); // 5 minutes in seconds
  const [zoom, setZoom] = useState(1);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const f = Math.floor((seconds % 1) * 24); // frames assuming 24fps
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}:${f.toString().padStart(2, '0')}`;
  };

  const getTrackIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video size={16} />;
      case 'audio':
        return <Music size={16} />;
      case 'text':
        return <Type size={16} />;
      case 'effects':
        return <Layers size={16} />;
      default:
        return null;
    }
  };

  return (
    <div className="h-64 bg-[#1a1a1a] border-t border-[#333] flex flex-col">
      {/* Timeline Header */}
      <div className="h-8 bg-[#252525] border-b border-[#333] flex items-center px-4 justify-between">
        <div className="flex items-center space-x-4">
          <Clock size={16} />
          <span className="font-mono text-sm">{formatTime(currentTime)}</span>
        </div>
        <div className="flex items-center space-x-4">
          <button className="px-2 py-1 bg-[#333] rounded text-sm hover:bg-[#444]">
            Add Track
          </button>
          <select className="bg-[#333] rounded px-2 py-1 text-sm">
            <option>24 fps</option>
            <option>30 fps</option>
            <option>60 fps</option>
          </select>
        </div>
      </div>

      {/* Timeline Ruler */}
      <div className="h-6 bg-[#252525] border-b border-[#333] relative">
        <div className="absolute inset-0 flex">
          {Array.from({ length: Math.ceil(duration / 60) }).map((_, i) => (
            <div key={i} className="flex-1 border-l border-[#333] relative">
              <span className="absolute -top-1 left-1 text-xs text-gray-400">
                {formatTime(i * 60)}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline Tracks */}
      <div className="flex-1 overflow-y-auto">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
        >
          <SortableContext
            items={tracks.map(t => t.id)}
            strategy={horizontalListSortingStrategy}
          >
            {tracks.map((track) => (
              <div
                key={track.id}
                className="h-16 border-b border-[#333] flex"
              >
                {/* Track Header */}
                <div className="w-48 bg-[#252525] border-r border-[#333] p-2 flex items-center space-x-2">
                  {getTrackIcon(track.type)}
                  <span className="text-sm">{track.type.charAt(0).toUpperCase() + track.type.slice(1)} Track</span>
                </div>
                {/* Track Content */}
                <div className="flex-1 bg-[#1a1a1a] relative">
                  {/* Placeholder for clips */}
                </div>
              </div>
            ))}
          </SortableContext>
        </DndContext>
      </div>
    </div>
  );
};