import React, { useState } from 'react';
import {
  Waveform,
  Play,
  Square,
  SkipBack,
  SkipForward,
  Volume2,
  Mic,
  Settings,
  Save,
  Share2,
  Sparkles,
  Sliders,
  Music,
  Wand2,
  Gauge,
  Plus,
  ChevronDown,
  Search,
} from 'lucide-react';

const AudioEditor = () => {
  const [currentTime, setCurrentTime] = useState('00:00:00');
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(75);
  const [selectedTrack, setSelectedTrack] = useState(null);
  const [zoomLevel, setZoomLevel] = useState(1);

  const tracks = [
    {
      id: 1,
      name: 'Main Vocals',
      waveform: 'https://images.unsplash.com/photo-1682687220742-aba19b51f319?w=800&fit=crop',
      color: '#4CAF50'
    },
    {
      id: 2,
      name: 'Background Music',
      waveform: 'https://images.unsplash.com/photo-1682687220742-aba19b51f319?w=800&fit=crop',
      color: '#2196F3'
    },
    {
      id: 3,
      name: 'Sound Effects',
      waveform: 'https://images.unsplash.com/photo-1682687220742-aba19b51f319?w=800&fit=crop',
      color: '#9C27B0'
    }
  ];

  return (
    <div className="h-screen bg-[#1a1a1a] text-white flex flex-col">
      {/* Top Bar */}
      <div className="h-12 bg-[#252525] border-b border-[#333] flex items-center justify-between px-4">
        <div className="flex items-center space-x-4">
          <h1 className="text-xl font-bold">Audio Editor</h1>
          <div className="flex space-x-2">
            <button className="px-3 py-1 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-1">
              <Save size={16} />
              <span>Save</span>
            </button>
            <button className="px-3 py-1 bg-[#333] rounded hover:bg-[#444] flex items-center space-x-1">
              <Share2 size={16} />
              <span>Export</span>
            </button>
            <button className="px-3 py-1 bg-blue-600 rounded hover:bg-blue-700 flex items-center space-x-1">
              <Sparkles size={16} />
              <span>AI Enhancement</span>
            </button>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-[#333] rounded px-2">
            <Gauge size={16} />
            <span className="text-sm">CPU: 45%</span>
          </div>
          <Settings size={20} className="cursor-pointer hover:text-blue-400" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Left Sidebar - Audio Library */}
        <div className="w-64 bg-[#252525] border-r border-[#333] flex flex-col">
          <div className="p-4 border-b border-[#333]">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold">Audio Library</h2>
              <Plus size={20} className="cursor-pointer hover:text-blue-400" />
            </div>
            <div className="relative">
              <input
                type="text"
                placeholder="Search audio files..."
                className="w-full bg-[#333] rounded px-3 py-2 pl-9 text-sm"
              />
              <Search size={16} className="absolute left-2 top-2.5 text-gray-400" />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4">
            {/* Audio Files List */}
            <div className="space-y-2">
              {tracks.map((track) => (
                <div
                  key={track.id}
                  className="p-2 rounded hover:bg-[#333] cursor-pointer flex items-center space-x-2"
                >
                  <Music size={16} className="text-gray-400" />
                  <span className="text-sm">{track.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col">
          {/* Waveform Display */}
          <div className="flex-1 p-4 bg-[#1a1a1a]">
            <div className="h-full rounded bg-[#252525] p-4">
              {/* Time Ruler */}
              <div className="h-6 mb-4 border-b border-[#333] relative">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute text-xs text-gray-400"
                    style={{ left: `${i * 10}%` }}
                  >
                    {i}:00
                  </div>
                ))}
              </div>
              {/* Audio Tracks */}
              <div className="space-y-4">
                {tracks.map((track) => (
                  <div
                    key={track.id}
                    className="h-24 bg-[#1a1a1a] rounded relative group"
                  >
                    <div className="absolute left-0 top-0 bottom-0 w-16 bg-[#333] flex items-center justify-center">
                      <span className="text-xs rotate-90">{track.name}</span>
                    </div>
                    <div
                      className="absolute left-16 right-0 top-0 bottom-0 bg-[#2a2a2a]"
                      style={{
                        backgroundImage: `linear-gradient(${track.color}22, ${track.color}22)`,
                      }}
                    >
                      {/* Waveform visualization would go here */}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Transport Controls */}
          <div className="h-20 bg-[#252525] border-t border-[#333] p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button className="p-2 hover:bg-[#333] rounded">
                  <SkipBack size={20} />
                </button>
                <button
                  className="p-2 hover:bg-[#333] rounded"
                  onClick={() => setIsPlaying(!isPlaying)}
                >
                  {isPlaying ? <Square size={20} /> : <Play size={20} />}
                </button>
                <button className="p-2 hover:bg-[#333] rounded">
                  <SkipForward size={20} />
                </button>
                <span className="font-mono">{currentTime}</span>
              </div>
              <div className="flex items-center space-x-4">
                <Volume2 size={20} />
                <div className="w-32 h-1 bg-[#333] rounded-full">
                  <div
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${volume}%` }}
                  ></div>
                </div>
                <span className="text-sm">{volume}%</span>
              </div>
              <div className="flex items-center space-x-4">
                <button className="px-3 py-1 bg-[#333] rounded hover:bg-[#444]">
                  <Mic size={16} />
                </button>
                <button className="px-3 py-1 bg-[#333] rounded hover:bg-[#444]">
                  <Wand2 size={16} />
                </button>
                <button className="px-3 py-1 bg-[#333] rounded hover:bg-[#444]">
                  <Sliders size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar - Effects & Properties */}
        <div className="w-80 bg-[#252525] border-l border-[#333] flex flex-col">
          <div className="p-4 border-b border-[#333]">
            <h2 className="font-semibold">Audio Properties</h2>
          </div>
          <div className="flex-1 p-4 space-y-4">
            <div>
              <label className="text-sm text-gray-400">Volume</label>
              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={(e) => setVolume(parseInt(e.target.value))}
                className="w-full"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400">Pan</label>
              <input
                type="range"
                min="-100"
                max="100"
                defaultValue="0"
                className="w-full"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400">Effects</label>
              <div className="space-y-2 mt-2">
                <button className="w-full p-2 bg-[#333] rounded hover:bg-[#444] text-left">
                  Reverb
                </button>
                <button className="w-full p-2 bg-[#333] rounded hover:bg-[#444] text-left">
                  Compression
                </button>
                <button className="w-full p-2 bg-[#333] rounded hover:bg-[#444] text-left">
                  EQ
                </button>
                <button className="w-full p-2 bg-[#333] rounded hover:bg-[#444] text-left">
                  Noise Reduction
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioEditor;